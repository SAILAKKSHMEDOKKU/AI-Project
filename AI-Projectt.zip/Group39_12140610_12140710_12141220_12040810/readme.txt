We have to excecute the python file
We have make UI interface application 
Here we can use commands "W" for Watering, "M" for Monitoring, "H" for Harvesting
We have also tried to remove weeds when they grow significantly
We have made multi- agent stimulation here
Here we shown the effect of change of day and night and climate conditions on the growth of the crop
We also shown the effect of watering by drones on the crop in an order (Irrigation)
We used Tractor to Harvest the over matured crops(Harvesting)
The drones are continuously monitoring the crops when we ask them
The weed plucking is done when weeds are grown significantly